// Demo 12 Js file
$(document).ready(function() {
    'use strict';
});