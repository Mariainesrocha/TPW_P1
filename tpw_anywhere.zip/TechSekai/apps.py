from django.apps import AppConfig


class TechsekaiConfig(AppConfig):
    name = 'TechSekai'
